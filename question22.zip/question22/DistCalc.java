/*
 * Name: Jiachen Zhang
 * Student number: 2098620
 */

public class DistCalc {
	
	public static double getDistance(String city1,String city2) {
		return 0;
	}

}
